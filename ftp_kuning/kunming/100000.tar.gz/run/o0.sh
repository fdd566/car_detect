./init0.sh
./open0.sh