cp update.sh ..
#while [ 1 ]
#do
#    procID=`pgrep test`
#    if [ "" == "$procID" ];
#    then
        ./test
#    fi
#    sleep 1
#done &
