cd /home/p
ifconfig eth0 192.168.1.222
./re.sh
