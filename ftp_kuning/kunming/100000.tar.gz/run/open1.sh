echo 1 > /sys/class/gpio/gpio149/value
sleep 1
echo 0 > /sys/class/gpio/gpio149/value