./init1.sh
./open1.sh