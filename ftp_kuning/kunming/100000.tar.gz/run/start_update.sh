cd..
./update.sh $1
