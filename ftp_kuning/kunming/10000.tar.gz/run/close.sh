echo 0 > /sys/class/gpio/gpio155/value
sleep 1
echo 1 > /sys/class/gpio/gpio155/value